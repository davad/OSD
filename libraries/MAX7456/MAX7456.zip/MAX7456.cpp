/*
  Arduino library for MAX7456 video overlay IC

  based on code from Arduino forum members dfraser and zitron
  http://www.arduino.cc/cgi-bin/yabb2/YaBB.pl?num=1220054359
  modified/extended by kg4wsv
  gmail: kg4wsv
*/

#include <WProgram.h>

#include "MAX7456.h"



byte MAX7456_spi_transfer(volatile char data)
{
  SPDR = data;                    // Start the transmission
  while (!(SPSR & (1<<SPIF)))     // Wait the end of the transmission
  {
  };
  return SPDR;                    // return the received byte
}


//#define MAX7456_spi_transfer(X) {SPDR = X; while (!(SPSR & (1<<SPIF))) {;}}

 


MAX7456::MAX7456()
{
  _slave_select = MAX7456SELECT;
  _char_attributes = 0x01;
  _cursor_x = CURSOR_X_MIN;
  _cursor_y = CURSOR_Y_MIN;
}


void MAX7456::begin(byte slave_select)
{
  _slave_select = slave_select;
  begin();
}


void MAX7456::begin()
{
  byte spi_junk;
  int x;

  pinMode(_slave_select,OUTPUT);
  digitalWrite(_slave_select,HIGH); //disable device

  pinMode(MAX7456_DATAOUT, OUTPUT);
  pinMode(MAX7456_DATAIN, INPUT);
  pinMode(MAX7456_SCK,OUTPUT);
//  pinMode(MAX7456_VSYNC, INPUT);

  // SPCR = 01010000
  //interrupt disabled,spi enabled,msb 1st,master,clk low when idle,
  //sample on leading edge of clk,system clock/4 rate (4 meg)

  MAX7456_previous_SPCR = SPCR;  // save SPCR, so we play nice with other SPI peripherals

  SPCR = (1<<SPE)|(1<<MSTR);
  spi_junk=SPSR;
  spi_junk=SPDR;
  delay(250);
  MAX7456_SPCR = SPCR;

  // force soft reset on MAX7456
  digitalWrite(_slave_select,LOW);
  MAX7456_spi_transfer(VM0_WRITE_ADDR);
  MAX7456_spi_transfer(MAX7456_reset);
  digitalWrite(_slave_select,HIGH);
  delay(500);

  // set all rows to same charactor white level, 90%
  digitalWrite(_slave_select,LOW);
  for (x = 0; x < MAX_screen_rows; x++)
  {
    MAX7456_spi_transfer(x + 0x10);
    MAX7456_spi_transfer(WHITE_level_90);
  }
  digitalWrite(_slave_select,HIGH);

  // make sure the MAX7456 is enabled
  digitalWrite(_slave_select,LOW);
  MAX7456_spi_transfer(VM0_WRITE_ADDR);
  MAX7456_spi_transfer(VERTICAL_SYNC_NEXT_VSYNC|OSD_ENABLE);
  digitalWrite(_slave_select,HIGH);
  delay(100);

  digitalWrite(_slave_select,LOW);
  MAX7456_spi_transfer(VM1_WRITE_ADDR);
  MAX7456_spi_transfer(BLINK_DUTY_CYCLE_75_25);
  digitalWrite(_slave_select,HIGH);
  delay(100);

  SPCR = MAX7456_previous_SPCR;   // restore SPCR
}

 

// clear the screen
void MAX7456::clear()
{
  MAX7456_previous_SPCR = SPCR;  // save SPCR, so we play nice with other SPI peripherals
  SPCR = MAX7456_SPCR;  // set SPCR to what we need

  digitalWrite(_slave_select,LOW);
  MAX7456_spi_transfer(DMM_WRITE_ADDR);
  MAX7456_spi_transfer(CLEAR_display);
  digitalWrite(_slave_select,HIGH);

  SPCR = MAX7456_previous_SPCR;   // restore SPCR

  _cursor_x = CURSOR_X_MIN;
  _cursor_y = CURSOR_Y_MIN;
} 

// send the cursor to home
void MAX7456::home()
{
  _cursor_x = CURSOR_X_MIN;
  _cursor_y = CURSOR_Y_MIN;
} 



// this is probably inefficient, as i simply modified a more general function
// that wrote arbitrary length strings. need to check modes of writing
// characters to MAX7456 to see if there's a better way to write one at a time
void MAX7456::write(uint8_t c)
{
  unsigned int linepos;
  byte char_address_hi, char_address_lo;

  if (c == '\n')
    {
      _cursor_y++;
      if (_cursor_y > CURSOR_Y_MAX)
	_cursor_y = CURSOR_Y_MIN;
      _cursor_x = CURSOR_X_MIN;
      return;
    }

  if (c == '\r')
    {
      _cursor_x = CURSOR_X_MIN;
      return;
    }


  MAX7456_previous_SPCR = SPCR;  // save SPCR, so we play nice with other SPI peripherals
  SPCR = MAX7456_SPCR;  // set SPCR to what we need

  char_address_hi = 0;
  char_address_lo = 0;
    
  // convert x,y to line position
  linepos = _cursor_y * 30 + _cursor_x;
  _cursor_x++;
  if (_cursor_x >= CURSOR_X_MAX)
    {
      _cursor_y++;
      if (_cursor_y > CURSOR_Y_MAX)
	_cursor_y = CURSOR_Y_MIN;
      _cursor_x = CURSOR_X_MIN;
    }

  
  // divide in to hi & lo byte
  char_address_hi = linepos >> 8;
  char_address_lo = linepos;
  
  
  digitalWrite(_slave_select,LOW);

  MAX7456_spi_transfer(DMM_WRITE_ADDR); //dmm
  MAX7456_spi_transfer(_char_attributes);

  MAX7456_spi_transfer(DMAH_WRITE_ADDR); // set start address high
  MAX7456_spi_transfer(char_address_hi);

  MAX7456_spi_transfer(DMAL_WRITE_ADDR); // set start address low
  MAX7456_spi_transfer(char_address_lo);
  
  
  MAX7456_spi_transfer(DMDI_WRITE_ADDR);
  MAX7456_spi_transfer(c);
  
  MAX7456_spi_transfer(DMDI_WRITE_ADDR);
  MAX7456_spi_transfer(END_string);
  
  MAX7456_spi_transfer(DMM_WRITE_ADDR); //dmm
  MAX7456_spi_transfer(B00000000);

  digitalWrite(_slave_select,HIGH);

  SPCR = MAX7456_previous_SPCR;   // restore SPCR
  
}


void MAX7456::write_to_screen(char s[], byte x, byte y)
{
  write_to_screen(s, x, y, 0, 0);
}

void MAX7456::write_to_screen(char s[], byte line)
{
  write_to_screen(s, 1, line, 0, 0);
}


void MAX7456::write_to_screen(char s[], byte x, byte y, byte blink, byte invert){
  unsigned int linepos;
  byte local_count;
  byte settings, char_address_hi, char_address_lo;
  byte screen_char;


  MAX7456_previous_SPCR = SPCR;  // save SPCR, so we play nice with other SPI peripherals
  SPCR = MAX7456_SPCR;  // set SPCR to what we need

  local_count = 0;

  char_address_hi = 0;
  char_address_lo = 0;
    
  // convert x,y to line position
  linepos = y*30+x;
  
  // divide in to hi & lo byte
  char_address_hi = linepos >> 8;
  char_address_lo = linepos;
  
  
  settings = B00000001;
  
  // set blink bit
  if (blink) {
    settings |= (1 << 4);       // forces nth bit of x to be 1.  all other bits left alone.
    //x &= ~(1 << n);      // forces nth bit of x to be 0.  all other bits left alone.  
  }
  // set invert bit
  if (invert){
    settings |= (1 << 3);       // forces nth bit of x to be 1.  all other bits left alone.
  }

  
  digitalWrite(_slave_select,LOW);

  MAX7456_spi_transfer(DMM_WRITE_ADDR); //dmm
  MAX7456_spi_transfer(settings);

  MAX7456_spi_transfer(DMAH_WRITE_ADDR); // set start address high
  MAX7456_spi_transfer(char_address_hi);

  MAX7456_spi_transfer(DMAL_WRITE_ADDR); // set start address low
  MAX7456_spi_transfer(char_address_lo);
  
  
  while(s[local_count]!='\0') // write out full screen
  {
    screen_char = s[local_count];
    MAX7456_spi_transfer(DMDI_WRITE_ADDR);
    MAX7456_spi_transfer(screen_char);
    local_count++;
  }
  
  MAX7456_spi_transfer(DMDI_WRITE_ADDR);
  MAX7456_spi_transfer(END_string);
  
  MAX7456_spi_transfer(DMM_WRITE_ADDR); //dmm
  MAX7456_spi_transfer(B00000000);

  digitalWrite(_slave_select,HIGH);

  SPCR = MAX7456_previous_SPCR;   // restore SPCR
} 


void MAX7456::blink(byte onoff)
{
  if (onoff)
    {
      _char_attributes |= 0x10;
    }
  else
    {
      _char_attributes &= ~0x10;
    }
}

void MAX7456::blink()
{
  blink(1);
}

void MAX7456::noBlink()
{
  blink(0);
}


void MAX7456::invert(byte onoff)
{
  if (onoff)
    {
      _char_attributes |= 0x08;
    }
  else
    {
      _char_attributes &= ~0x08;
    }
}

void MAX7456::invert()
{
  invert(1);
}

void MAX7456::noInvert()
{
  invert(0);
}
